# ==============================================================================
# modules/monitoring/main.tf
# CloudWatch Alarms, Dashboard, and SNS for the ETL pipeline
# ==============================================================================

# ------------------------------------------------------------------------------
# SNS Topic for alerts
# ------------------------------------------------------------------------------
resource "aws_sns_topic" "alarms" {
  name              = "${var.project}-${var.env}-alarms"
  kms_master_key_id = "alias/aws/sns"
}

resource "aws_sns_topic_subscription" "email" {
  topic_arn = aws_sns_topic.alarms.arn
  protocol  = "email"
  endpoint  = var.alarm_email
}

# ------------------------------------------------------------------------------
# Lambda Alarms
# ------------------------------------------------------------------------------
resource "aws_cloudwatch_metric_alarm" "lambda_errors" {
  alarm_name          = "${var.project}-lambda-errors"
  alarm_description   = "ETL trigger Lambda is throwing errors"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "Sum"
  threshold           = var.lambda_error_threshold
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = var.lambda_function_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "lambda_duration" {
  alarm_name          = "${var.project}-lambda-high-duration"
  alarm_description   = "Lambda execution time is approaching the timeout limit"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "Duration"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "p95"
  threshold           = var.lambda_timeout_ms * 0.8   # Alarm at 80% of timeout
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = var.lambda_function_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "lambda_throttles" {
  alarm_name          = "${var.project}-lambda-throttles"
  alarm_description   = "Lambda is being throttled — consider raising concurrency limits"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Throttles"
  namespace           = "AWS/Lambda"
  period              = 60
  statistic           = "Sum"
  threshold           = 0
  treat_missing_data  = "notBreaching"

  dimensions = {
    FunctionName = var.lambda_function_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

# ------------------------------------------------------------------------------
# ECS Alarms
# ------------------------------------------------------------------------------
resource "aws_cloudwatch_metric_alarm" "ecs_task_failures" {
  alarm_name          = "${var.project}-ecs-task-failures"
  alarm_description   = "ECS ETL worker tasks are stopping unexpectedly"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "FailedTaskCount"
  namespace           = "ECS/ContainerInsights"
  period              = 60
  statistic           = "Sum"
  threshold           = var.ecs_task_failure_threshold
  treat_missing_data  = "notBreaching"

  dimensions = {
    ClusterName = var.ecs_cluster_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "ecs_cpu_high" {
  alarm_name          = "${var.project}-ecs-cpu-high"
  alarm_description   = "ECS cluster CPU utilization is very high"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "CpuUtilized"
  namespace           = "ECS/ContainerInsights"
  period              = 60
  statistic           = "Average"
  threshold           = 90
  treat_missing_data  = "notBreaching"

  dimensions = {
    ClusterName = var.ecs_cluster_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "ecs_memory_high" {
  alarm_name          = "${var.project}-ecs-memory-high"
  alarm_description   = "ECS cluster memory utilization is very high"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "MemoryUtilized"
  namespace           = "ECS/ContainerInsights"
  period              = 60
  statistic           = "Average"
  threshold           = 85
  treat_missing_data  = "notBreaching"

  dimensions = {
    ClusterName = var.ecs_cluster_name
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

# ------------------------------------------------------------------------------
# Aurora Alarms
# ------------------------------------------------------------------------------
resource "aws_cloudwatch_metric_alarm" "aurora_cpu" {
  alarm_name          = "${var.project}-aurora-cpu-high"
  alarm_description   = "Aurora cluster CPU is above threshold"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "CPUUtilization"
  namespace           = "AWS/RDS"
  period              = 60
  statistic           = "Average"
  threshold           = var.aurora_cpu_threshold
  treat_missing_data  = "notBreaching"

  dimensions = {
    DBClusterIdentifier = var.aurora_cluster_id
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
  ok_actions    = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "aurora_connections" {
  alarm_name          = "${var.project}-aurora-connections-high"
  alarm_description   = "Aurora is approaching max database connections"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "DatabaseConnections"
  namespace           = "AWS/RDS"
  period              = 60
  statistic           = "Average"
  threshold           = var.aurora_connections_threshold
  treat_missing_data  = "notBreaching"

  dimensions = {
    DBClusterIdentifier = var.aurora_cluster_id
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "aurora_deadlocks" {
  alarm_name          = "${var.project}-aurora-deadlocks"
  alarm_description   = "Aurora is experiencing deadlocks"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "Deadlocks"
  namespace           = "AWS/RDS"
  period              = 60
  statistic           = "Sum"
  threshold           = 0
  treat_missing_data  = "notBreaching"

  dimensions = {
    DBClusterIdentifier = var.aurora_cluster_id
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "aurora_replication_lag" {
  alarm_name          = "${var.project}-aurora-replication-lag"
  alarm_description   = "Aurora reader is lagging behind the writer by more than 1 second"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "AuroraReplicaLag"
  namespace           = "AWS/RDS"
  period              = 60
  statistic           = "Maximum"
  threshold           = 1000  # milliseconds
  treat_missing_data  = "notBreaching"

  dimensions = {
    DBClusterIdentifier = var.aurora_cluster_id
  }

  alarm_actions = [aws_sns_topic.alarms.arn]
}

# ------------------------------------------------------------------------------
# CloudWatch Log Metric Filters (custom metrics from logs)
# ------------------------------------------------------------------------------
resource "aws_cloudwatch_log_metric_filter" "ecs_etl_errors" {
  name           = "${var.project}-ecs-etl-errors"
  log_group_name = "/ecs/${var.project}-etl-worker"
  pattern        = "[timestamp, level=ERROR, ...]"

  metric_transformation {
    name          = "ETLWorkerErrors"
    namespace     = "${var.project}/ETL"
    value         = "1"
    default_value = "0"
  }
}

resource "aws_cloudwatch_metric_alarm" "ecs_etl_log_errors" {
  alarm_name          = "${var.project}-ecs-etl-log-errors"
  alarm_description   = "ETL worker logged ERROR-level messages"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "ETLWorkerErrors"
  namespace           = "${var.project}/ETL"
  period              = 60
  statistic           = "Sum"
  threshold           = 0
  treat_missing_data  = "notBreaching"

  alarm_actions = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_log_metric_filter" "ecs_etl_rows_processed" {
  name           = "${var.project}-ecs-rows-processed"
  log_group_name = "/ecs/${var.project}-etl-worker"
  pattern        = "[timestamp, level, msg=\"Rows processed:\", count]"

  metric_transformation {
    name      = "RowsProcessed"
    namespace = "${var.project}/ETL"
    value     = "$count"
  }
}

# ------------------------------------------------------------------------------
# CloudWatch Dashboard
# ------------------------------------------------------------------------------
resource "aws_cloudwatch_dashboard" "etl" {
  dashboard_name = "${var.project}-${var.env}"

  dashboard_body = jsonencode({
    widgets = [
      # ── Row 1: Lambda ──────────────────────────────────────────────────────
      {
        type       = "metric"
        x = 0; y = 0; width = 8; height = 6
        properties = {
          title  = "Lambda — Invocations & Errors"
          region = var.aws_region
          metrics = [
            ["AWS/Lambda", "Invocations", "FunctionName", var.lambda_function_name, { stat = "Sum", label = "Invocations" }],
            ["AWS/Lambda", "Errors",      "FunctionName", var.lambda_function_name, { stat = "Sum", label = "Errors", color = "#d62728" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
      {
        type       = "metric"
        x = 8; y = 0; width = 8; height = 6
        properties = {
          title  = "Lambda — Duration (p50 / p95 / p99)"
          region = var.aws_region
          metrics = [
            ["AWS/Lambda", "Duration", "FunctionName", var.lambda_function_name, { stat = "p50", label = "p50" }],
            ["AWS/Lambda", "Duration", "FunctionName", var.lambda_function_name, { stat = "p95", label = "p95" }],
            ["AWS/Lambda", "Duration", "FunctionName", var.lambda_function_name, { stat = "p99", label = "p99" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
      {
        type       = "alarm"
        x = 16; y = 0; width = 8; height = 6
        properties = {
          title  = "Active Alarms"
          alarms = [
            aws_cloudwatch_metric_alarm.lambda_errors.arn,
            aws_cloudwatch_metric_alarm.lambda_throttles.arn,
            aws_cloudwatch_metric_alarm.ecs_task_failures.arn,
            aws_cloudwatch_metric_alarm.aurora_cpu.arn,
            aws_cloudwatch_metric_alarm.aurora_deadlocks.arn,
          ]
        }
      },
      # ── Row 2: ECS ─────────────────────────────────────────────────────────
      {
        type       = "metric"
        x = 0; y = 6; width = 8; height = 6
        properties = {
          title  = "ECS — Running Tasks"
          region = var.aws_region
          metrics = [
            ["ECS/ContainerInsights", "RunningTaskCount", "ClusterName", var.ecs_cluster_name, { stat = "Average" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
      {
        type       = "metric"
        x = 8; y = 6; width = 8; height = 6
        properties = {
          title  = "ECS — CPU & Memory Utilization"
          region = var.aws_region
          metrics = [
            ["ECS/ContainerInsights", "CpuUtilized",    "ClusterName", var.ecs_cluster_name, { stat = "Average", label = "CPU %" }],
            ["ECS/ContainerInsights", "MemoryUtilized", "ClusterName", var.ecs_cluster_name, { stat = "Average", label = "Memory %" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
      {
        type       = "metric"
        x = 16; y = 6; width = 8; height = 6
        properties = {
          title  = "ETL — Rows Processed"
          region = var.aws_region
          metrics = [
            ["${var.project}/ETL", "RowsProcessed", { stat = "Sum", label = "Rows" }],
          ]
          view   = "timeSeries"
          period = 300
        }
      },
      # ── Row 3: Aurora ──────────────────────────────────────────────────────
      {
        type       = "metric"
        x = 0; y = 12; width = 8; height = 6
        properties = {
          title  = "Aurora — CPU Utilization"
          region = var.aws_region
          metrics = [
            ["AWS/RDS", "CPUUtilization", "DBClusterIdentifier", var.aurora_cluster_id, { stat = "Average" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
      {
        type       = "metric"
        x = 8; y = 12; width = 8; height = 6
        properties = {
          title  = "Aurora — Connections & Deadlocks"
          region = var.aws_region
          metrics = [
            ["AWS/RDS", "DatabaseConnections", "DBClusterIdentifier", var.aurora_cluster_id, { stat = "Average", label = "Connections" }],
            ["AWS/RDS", "Deadlocks",           "DBClusterIdentifier", var.aurora_cluster_id, { stat = "Sum",     label = "Deadlocks", color = "#d62728" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
      {
        type       = "metric"
        x = 16; y = 12; width = 8; height = 6
        properties = {
          title  = "Aurora — Replica Lag (ms)"
          region = var.aws_region
          metrics = [
            ["AWS/RDS", "AuroraReplicaLag", "DBClusterIdentifier", var.aurora_cluster_id, { stat = "Maximum" }],
          ]
          view   = "timeSeries"
          period = 60
        }
      },
    ]
  })
}

# ------------------------------------------------------------------------------
# Variables
# ------------------------------------------------------------------------------
variable "project"               { type = string }
variable "env"                   { type = string }
variable "aws_region"            { type = string }
variable "alarm_email"           { type = string }
variable "lambda_function_name"  { type = string }
variable "lambda_timeout_ms"     { type = number }
variable "ecs_cluster_name"      { type = string }
variable "aurora_cluster_id"     { type = string }
variable "lambda_error_threshold"        { type = number; default = 1 }
variable "ecs_task_failure_threshold"    { type = number; default = 1 }
variable "aurora_cpu_threshold"          { type = number; default = 80 }
variable "aurora_connections_threshold"  { type = number; default = 200 }

# ------------------------------------------------------------------------------
# Outputs
# ------------------------------------------------------------------------------
output "sns_topic_arn" {
  value = aws_sns_topic.alarms.arn
}

output "dashboard_name" {
  value = aws_cloudwatch_dashboard.etl.dashboard_name
}
