# ==============================================================================
# outputs.tf — Root Module
# ETL Data Pipeline on AWS
# ==============================================================================

# ------------------------------------------------------------------------------
# Networking
# ------------------------------------------------------------------------------
output "vpc_id" {
  description = "ID of the VPC"
  value       = module.networking.vpc_id
}

output "private_subnet_ids" {
  description = "IDs of private subnets (ECS / RDS live here)"
  value       = module.networking.private_subnet_ids
}

output "public_subnet_ids" {
  description = "IDs of public subnets (NAT gateway lives here)"
  value       = module.networking.public_subnet_ids
}

# ------------------------------------------------------------------------------
# S3 Buckets
# ------------------------------------------------------------------------------
output "s3_raw_bucket_name" {
  description = "Name of the raw data S3 bucket (drop files here to trigger ETL)"
  value       = module.s3.raw_bucket_name
}

output "s3_raw_bucket_arn" {
  description = "ARN of the raw data S3 bucket"
  value       = module.s3.raw_bucket_arn
}

output "s3_processed_bucket_name" {
  description = "Name of the processed/staging S3 bucket"
  value       = module.s3.processed_bucket_name
}

output "s3_reports_bucket_name" {
  description = "Name of the reports S3 bucket (served via CloudFront)"
  value       = module.s3.reports_bucket_name
}

# ------------------------------------------------------------------------------
# Lambda
# ------------------------------------------------------------------------------
output "lambda_trigger_arn" {
  description = "ARN of the ETL trigger Lambda function"
  value       = module.lambda.trigger_arn
}

output "lambda_trigger_name" {
  description = "Name of the ETL trigger Lambda function"
  value       = module.lambda.trigger_name
}

output "lambda_log_group" {
  description = "CloudWatch log group for the Lambda trigger"
  value       = "/aws/lambda/${module.lambda.trigger_name}"
}

# ------------------------------------------------------------------------------
# ECS / Fargate
# ------------------------------------------------------------------------------
output "ecs_cluster_name" {
  description = "Name of the ECS cluster"
  value       = module.ecs.cluster_name
}

output "ecs_cluster_arn" {
  description = "ARN of the ECS cluster"
  value       = module.ecs.cluster_arn
}

output "ecs_task_definition_arn" {
  description = "ARN of the latest ECS task definition revision"
  value       = module.ecs.task_def_arn
}

output "ecs_task_definition_family" {
  description = "Family name of the ECS task definition"
  value       = module.ecs.task_def_family
}

output "ecs_worker_security_group_id" {
  description = "Security group attached to ECS Fargate tasks"
  value       = module.ecs.worker_sg_id
}

output "ecs_log_group" {
  description = "CloudWatch log group for ECS tasks"
  value       = "/ecs/${var.project}-etl-worker"
}

# ------------------------------------------------------------------------------
# RDS / Aurora
# ------------------------------------------------------------------------------
output "aurora_cluster_id" {
  description = "Aurora cluster identifier"
  value       = module.rds.cluster_id
}

output "aurora_cluster_endpoint" {
  description = "Writer endpoint for the Aurora cluster (use for INSERT/UPDATE)"
  value       = module.rds.cluster_endpoint
  sensitive   = true
}

output "aurora_reader_endpoint" {
  description = "Reader endpoint for the Aurora cluster (use for SELECT)"
  value       = module.rds.reader_endpoint
  sensitive   = true
}

output "aurora_port" {
  description = "Port the Aurora cluster listens on"
  value       = module.rds.port
}

output "aurora_database_name" {
  description = "Name of the default database"
  value       = module.rds.database_name
}

output "aurora_secret_arn" {
  description = "Secrets Manager ARN containing the Aurora master password"
  value       = module.rds.password_secret_arn
  sensitive   = true
}

# Convenience: connection string (without password)
output "aurora_connection_string_template" {
  description = "Aurora connection string template (password retrieved from Secrets Manager)"
  value       = "postgresql://${var.db_username}:<SECRET>@${module.rds.cluster_endpoint}:${module.rds.port}/${var.db_name}"
  sensitive   = true
}

# ------------------------------------------------------------------------------
# CloudFront / Reports
# ------------------------------------------------------------------------------
output "cloudfront_distribution_id" {
  description = "CloudFront distribution ID (use to invalidate cache)"
  value       = module.cloudfront.distribution_id
}

output "cloudfront_domain_name" {
  description = "CloudFront distribution domain name"
  value       = module.cloudfront.domain_name
}

output "cloudfront_reports_url" {
  description = "Base URL for accessing reports via CloudFront"
  value       = "https://${module.cloudfront.domain_name}"
}

# ------------------------------------------------------------------------------
# ECR
# ------------------------------------------------------------------------------
output "ecr_repository_url" {
  description = "ECR repository URL — push your ETL worker image here"
  value       = module.ecr.repository_url
}

output "ecr_repository_name" {
  description = "ECR repository name"
  value       = module.ecr.repository_name
}

output "ecr_docker_login_command" {
  description = "Command to authenticate Docker with ECR"
  value       = "aws ecr get-login-password --region ${var.aws_region} | docker login --username AWS --password-stdin ${module.ecr.repository_url}"
}

# ------------------------------------------------------------------------------
# Monitoring
# ------------------------------------------------------------------------------
output "sns_alarm_topic_arn" {
  description = "SNS topic ARN for CloudWatch alarm notifications"
  value       = module.monitoring.sns_topic_arn
}

output "cloudwatch_dashboard_url" {
  description = "URL to the CloudWatch dashboard"
  value       = "https://${var.aws_region}.console.aws.amazon.com/cloudwatch/home?region=${var.aws_region}#dashboards:name=${var.project}-${var.env}"
}

# ------------------------------------------------------------------------------
# Useful CLI snippets
# ------------------------------------------------------------------------------
output "cli_run_etl_manually" {
  description = "AWS CLI command to manually trigger an ECS ETL task"
  value       = <<-EOT
    aws ecs run-task \
      --cluster ${module.ecs.cluster_name} \
      --task-definition ${module.ecs.task_def_family} \
      --launch-type FARGATE \
      --network-configuration "awsvpcConfiguration={subnets=[${join(",", module.networking.private_subnet_ids)}],securityGroups=[${module.ecs.worker_sg_id}],assignPublicIp=DISABLED}" \
      --overrides '{"containerOverrides":[{"name":"etl-worker","environment":[{"name":"SOURCE_BUCKET","value":"YOUR_BUCKET"},{"name":"SOURCE_KEY","value":"incoming/your-file.csv"}]}]}'
  EOT
}

output "cli_get_db_password" {
  description = "AWS CLI command to retrieve the Aurora password from Secrets Manager"
  value       = "aws secretsmanager get-secret-value --secret-id ${module.rds.password_secret_arn} --query SecretString --output text"
  sensitive   = true
}
