# ==============================================================================
# variables.tf — Root Module
# ETL Data Pipeline on AWS
# ==============================================================================

# ------------------------------------------------------------------------------
# General
# ------------------------------------------------------------------------------
variable "project" {
  description = "Short project name used as prefix for all resources"
  type        = string
  default     = "etl-pipeline"

  validation {
    condition     = can(regex("^[a-z0-9-]{3,20}$", var.project))
    error_message = "Project name must be 3–20 chars, lowercase alphanumeric and hyphens only."
  }
}

variable "env" {
  description = "Deployment environment"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.env)
    error_message = "env must be one of: dev, staging, prod."
  }
}

variable "aws_region" {
  description = "AWS region to deploy resources into"
  type        = string
  default     = "us-east-1"
}

variable "tags" {
  description = "Additional tags to merge onto all resources"
  type        = map(string)
  default     = {}
}

# ------------------------------------------------------------------------------
# Networking
# ------------------------------------------------------------------------------
variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"

  validation {
    condition     = can(cidrhost(var.vpc_cidr, 0))
    error_message = "vpc_cidr must be a valid CIDR block."
  }
}

variable "availability_zones" {
  description = "List of AZs to spread subnets across (min 2 for RDS)"
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b"]
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets (one per AZ)"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets (one per AZ, used for NAT GW)"
  type        = list(string)
  default     = ["10.0.11.0/24", "10.0.12.0/24"]
}

# ------------------------------------------------------------------------------
# S3
# ------------------------------------------------------------------------------
variable "s3_raw_prefix" {
  description = "S3 key prefix that triggers the ETL Lambda"
  type        = string
  default     = "incoming/"
}

variable "s3_raw_suffix" {
  description = "S3 key suffix filter for the Lambda trigger"
  type        = string
  default     = ".csv"
}

variable "s3_lifecycle_raw_days" {
  description = "Days after which raw objects transition to S3-IA"
  type        = number
  default     = 30
}

variable "s3_lifecycle_raw_expire_days" {
  description = "Days after which raw objects are deleted (0 = disabled)"
  type        = number
  default     = 365
}

# ------------------------------------------------------------------------------
# Lambda
# ------------------------------------------------------------------------------
variable "lambda_runtime" {
  description = "Lambda runtime for the ETL trigger function"
  type        = string
  default     = "python3.12"
}

variable "lambda_timeout" {
  description = "Lambda function timeout in seconds"
  type        = number
  default     = 60

  validation {
    condition     = var.lambda_timeout >= 10 && var.lambda_timeout <= 900
    error_message = "Lambda timeout must be between 10 and 900 seconds."
  }
}

variable "lambda_memory" {
  description = "Lambda memory allocation in MB"
  type        = number
  default     = 256
}

variable "lambda_log_retention_days" {
  description = "CloudWatch log retention for Lambda in days"
  type        = number
  default     = 30
}

# ------------------------------------------------------------------------------
# ECS / Fargate
# ------------------------------------------------------------------------------
variable "ecs_task_cpu" {
  description = "CPU units for the ECS Fargate task (256, 512, 1024, 2048, 4096)"
  type        = number
  default     = 1024

  validation {
    condition     = contains([256, 512, 1024, 2048, 4096], var.ecs_task_cpu)
    error_message = "ecs_task_cpu must be one of: 256, 512, 1024, 2048, 4096."
  }
}

variable "ecs_task_memory" {
  description = "Memory (MB) for the ECS Fargate task"
  type        = number
  default     = 2048
}

variable "ecs_log_retention_days" {
  description = "CloudWatch log retention for ECS in days"
  type        = number
  default     = 30
}

variable "ecr_repo_url" {
  description = "ECR repository URL for the ETL worker Docker image"
  type        = string
}

variable "ecr_image_tag" {
  description = "Docker image tag to deploy"
  type        = string
  default     = "latest"
}

# ------------------------------------------------------------------------------
# RDS / Aurora
# ------------------------------------------------------------------------------
variable "db_name" {
  description = "Name of the default database in Aurora"
  type        = string
  default     = "etldb"

  validation {
    condition     = can(regex("^[a-zA-Z][a-zA-Z0-9_]{1,62}$", var.db_name))
    error_message = "db_name must start with a letter and contain only alphanumeric/underscore chars."
  }
}

variable "db_username" {
  description = "Master username for the Aurora cluster"
  type        = string
  default     = "etladmin"
  sensitive   = true
}

variable "aurora_engine_version" {
  description = "Aurora PostgreSQL engine version"
  type        = string
  default     = "15.4"
}

variable "aurora_min_capacity" {
  description = "Aurora Serverless v2 minimum ACU capacity"
  type        = number
  default     = 0.5
}

variable "aurora_max_capacity" {
  description = "Aurora Serverless v2 maximum ACU capacity"
  type        = number
  default     = 8.0
}

variable "aurora_instance_count" {
  description = "Number of Aurora instances (1 writer + N-1 readers)"
  type        = number
  default     = 2

  validation {
    condition     = var.aurora_instance_count >= 1 && var.aurora_instance_count <= 5
    error_message = "aurora_instance_count must be between 1 and 5."
  }
}

variable "aurora_deletion_protection" {
  description = "Enable deletion protection on the Aurora cluster"
  type        = bool
  default     = true
}

variable "aurora_backup_retention_days" {
  description = "Number of days to retain Aurora automated backups"
  type        = number
  default     = 7
}

# ------------------------------------------------------------------------------
# CloudFront / Reports
# ------------------------------------------------------------------------------
variable "cloudfront_price_class" {
  description = "CloudFront price class for the reports distribution"
  type        = string
  default     = "PriceClass_100" # US, Canada, Europe

  validation {
    condition     = contains(["PriceClass_100", "PriceClass_200", "PriceClass_All"], var.cloudfront_price_class)
    error_message = "cloudfront_price_class must be PriceClass_100, PriceClass_200, or PriceClass_All."
  }
}

variable "cloudfront_default_ttl" {
  description = "Default CloudFront cache TTL in seconds"
  type        = number
  default     = 3600
}

variable "acm_certificate_arn" {
  description = "ACM certificate ARN for custom CloudFront domain (leave empty for default *.cloudfront.net)"
  type        = string
  default     = ""
}

variable "cloudfront_custom_domain" {
  description = "Custom domain for CloudFront distribution (leave empty to use default)"
  type        = string
  default     = ""
}

# ------------------------------------------------------------------------------
# Monitoring & Alerting
# ------------------------------------------------------------------------------
variable "alarm_email" {
  description = "Email address for CloudWatch alarm SNS notifications"
  type        = string
}

variable "lambda_error_threshold" {
  description = "Lambda error count threshold before alarming"
  type        = number
  default     = 1
}

variable "ecs_task_failure_threshold" {
  description = "ECS stopped task count threshold before alarming"
  type        = number
  default     = 1
}

variable "aurora_cpu_threshold" {
  description = "Aurora CPU utilization % threshold before alarming"
  type        = number
  default     = 80
}

variable "aurora_connections_threshold" {
  description = "Aurora DB connection count threshold before alarming"
  type        = number
  default     = 200
}
