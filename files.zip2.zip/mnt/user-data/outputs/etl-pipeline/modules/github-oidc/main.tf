# ==============================================================================
# modules/github-oidc/main.tf
# Federated IAM role for GitHub Actions — no long-lived AWS keys needed
# ==============================================================================

data "aws_caller_identity" "current" {}
data "aws_partition"       "current" {}

# Trust the GitHub OIDC provider
data "aws_iam_openid_connect_provider" "github" {
  url = "https://token.actions.githubusercontent.com"
}

resource "aws_iam_role" "github_actions" {
  name        = "${var.project}-github-actions"
  description = "Role assumed by GitHub Actions via OIDC for ${var.project}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = data.aws_iam_openid_connect_provider.github.arn }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
        StringLike = {
          # Restrict to your org/repo — change this!
          "token.actions.githubusercontent.com:sub" = "repo:${var.github_org}/${var.github_repo}:*"
        }
      }
    }]
  })
}

# Policy: what GitHub Actions CI can do
resource "aws_iam_role_policy" "github_actions" {
  role = aws_iam_role.github_actions.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      # Terraform state (S3 + DynamoDB locking)
      {
        Sid    = "TerraformState"
        Effect = "Allow"
        Action = [
          "s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket"
        ]
        Resource = [
          "arn:aws:s3:::${var.tf_state_bucket}",
          "arn:aws:s3:::${var.tf_state_bucket}/*"
        ]
      },
      {
        Sid    = "TerraformStateLock"
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem", "dynamodb:PutItem",
          "dynamodb:DeleteItem", "dynamodb:DescribeTable"
        ]
        Resource = "arn:aws:dynamodb:*:${data.aws_caller_identity.current.account_id}:table/${var.tf_state_lock_table}"
      },
      # ECR — push images
      {
        Sid    = "ECRAuth"
        Effect = "Allow"
        Action = ["ecr:GetAuthorizationToken"]
        Resource = "*"
      },
      {
        Sid    = "ECRPush"
        Effect = "Allow"
        Action = [
          "ecr:BatchCheckLayerAvailability", "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage", "ecr:PutImage",
          "ecr:InitiateLayerUpload", "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload", "ecr:DescribeRepositories",
          "ecr:GetRepositoryPolicy", "ecr:ListImages",
          "ecr:DescribeImages"
        ]
        Resource = "arn:aws:ecr:*:${data.aws_caller_identity.current.account_id}:repository/${var.project}-worker"
      },
      # Terraform — broad enough to manage the pipeline resources
      # In production, tighten this per service
      {
        Sid    = "TerraformDeploy"
        Effect = "Allow"
        Action = [
          "iam:*", "lambda:*", "ecs:*", "ec2:*",
          "s3:*", "rds:*", "secretsmanager:*",
          "cloudfront:*", "cloudwatch:*", "logs:*",
          "sns:*", "events:*", "sts:GetCallerIdentity"
        ]
        Resource = "*"
      }
    ]
  })
}

# ------------------------------------------------------------------------------
# Variables
# ------------------------------------------------------------------------------
variable "project"             { type = string }
variable "github_org"          { type = string }
variable "github_repo"         { type = string }
variable "tf_state_bucket"     { type = string }
variable "tf_state_lock_table" { type = string }

# ------------------------------------------------------------------------------
# Outputs
# ------------------------------------------------------------------------------
output "role_arn"  { value = aws_iam_role.github_actions.arn }
output "role_name" { value = aws_iam_role.github_actions.name }
