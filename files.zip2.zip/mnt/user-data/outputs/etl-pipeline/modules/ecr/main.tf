# ==============================================================================
# modules/ecr/main.tf
# ECR repository for the ETL worker Docker image
# ==============================================================================

resource "aws_ecr_repository" "etl_worker" {
  name                 = "${var.project}-worker"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true   # Auto-scan every image for CVEs
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = {
    Name = "${var.project}-worker"
  }
}

# ------------------------------------------------------------------------------
# Lifecycle policy — keep only the last 10 tagged images + untagged < 1 day
# ------------------------------------------------------------------------------
resource "aws_ecr_lifecycle_policy" "etl_worker" {
  repository = aws_ecr_repository.etl_worker.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Expire untagged images older than 1 day"
        selection = {
          tagStatus   = "untagged"
          countType   = "sinceImagePushed"
          countUnit   = "days"
          countNumber = 1
        }
        action = { type = "expire" }
      },
      {
        rulePriority = 2
        description  = "Keep only the last 10 tagged images"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["v", "latest", "release"]
          countType     = "imageCountMoreThan"
          countNumber   = 10
        }
        action = { type = "expire" }
      }
    ]
  })
}

# ------------------------------------------------------------------------------
# Repository policy — allow ECS task role to pull images
# ------------------------------------------------------------------------------
data "aws_caller_identity" "current" {}

resource "aws_ecr_repository_policy" "etl_worker" {
  repository = aws_ecr_repository.etl_worker.name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowECSTaskPull"
        Effect = "Allow"
        Principal = {
          AWS = var.ecs_task_execution_role_arn
        }
        Action = [
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
          "ecr:BatchCheckLayerAvailability"
        ]
      },
      {
        Sid    = "AllowGitHubActionsCI"
        Effect = "Allow"
        Principal = {
          AWS = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/${var.project}-github-actions"
        }
        Action = [
          "ecr:GetDownloadUrlForLayer",
          "ecr:BatchGetImage",
          "ecr:BatchCheckLayerAvailability",
          "ecr:PutImage",
          "ecr:InitiateLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:CompleteLayerUpload",
          "ecr:DescribeRepositories",
          "ecr:GetRepositoryPolicy",
          "ecr:ListImages"
        ]
      }
    ]
  })
}

# ------------------------------------------------------------------------------
# Variables
# ------------------------------------------------------------------------------
variable "project"                    { type = string }
variable "ecs_task_execution_role_arn" { type = string }

# ------------------------------------------------------------------------------
# Outputs
# ------------------------------------------------------------------------------
output "repository_url"  { value = aws_ecr_repository.etl_worker.repository_url }
output "repository_name" { value = aws_ecr_repository.etl_worker.name }
output "repository_arn"  { value = aws_ecr_repository.etl_worker.arn }
